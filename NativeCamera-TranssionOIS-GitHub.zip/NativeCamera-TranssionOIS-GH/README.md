# Native Camera + Transsion OIS

Автоматическая сборка патченного **Native Camera** с принудительным включением Transsion OIS.

## Как пользоваться (с телефона)

### 1. Создай репозиторий на GitHub
- Зайди на github.com → New repository
- Назови как угодно (например `NativeCamera-TranssionOIS`)
- **Не** ставь галочку "Add a README"

### 2. Загрузи файлы
Самый простой способ с телефона:

1. Скачай этот архив
2. Распакуй
3. Зайди в свой новый репозиторий на GitHub
4. Нажми **Add file → Upload files**
5. Загрузи **всю папку** (original, smali_patch, .github, README.md и т.д.)
6. Commit changes

### 3. Запусти сборку
1. Перейди во вкладку **Actions**
2. Выбери workflow **"Build Native Camera + Transsion OIS"**
3. Нажми **Run workflow** → **Run workflow**
4. Подожди 2–4 минуты
5. Когда сборка станет зелёной — скачай артефакт **NativeCamera-TranssionOIS**

Внутри будет готовый подписанный APK.

---

## Что делает патч

В метод, который выставляет стабилизацию, добавляется:

```smali
com.transsion.tranOisMode = int[]{1}
```

Это принудительно включает фирменный Transsion OIS.  
UI приложения не меняется.

Значение `1` — кандидат на ON. Если на твоём устройстве окажется, что нужно `3` — скажи, поменяю.

## Проверка после установки

```bash
adb logcat | grep -E "RawCamManager|Transsion"
```

Должно появиться:
```
Applied Transsion OIS vendor tag: tranOisMode=1
```

## Важно

- Работает только на устройствах Transsion / TECNO / Infinix с поддержкой этого vendor-тега.
- На других брендах патч просто ничего не сделает (приложение не упадёт).
