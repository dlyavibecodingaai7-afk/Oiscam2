package com.example.camera;

import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;

import java.util.Arrays;
import java.util.List;

/**
 * Minimal helper for probing and submitting the Transsion OIS Camera2 vendor tag.
 *
 * IMPORTANT:
 * - This class does not define which raw value means ON or OFF.
 * - The values 1 and 3 must be mapped only after hardware/firmware testing.
 * - It intentionally does not modify the standard Android OIS or EIS keys.
 * - A successful CaptureRequest.Builder.set() does not prove that the HAL
 *   physically enabled optical stabilization.
 */
public final class TranssionOisController {
    public static final String CHARACTERISTIC_SUPPORT_TAG =
            "com.transsion.tranOisSupport";
    public static final String REQUEST_MODE_TAG =
            "com.transsion.tranOisMode";

    /** Candidate raw values copied from the TECNO OIS Probe project. */
    public static final int CANDIDATE_RAW_VALUE_1 = 1;
    public static final int CANDIDATE_RAW_VALUE_3 = 3;

    private TranssionOisController() {
        // Utility class.
    }

    /**
     * Inspects whether this camera publishes the expected Transsion keys.
     * The support characteristic is read only when it is advertised as int[].
     */
    public static SupportInfo inspect(CameraCharacteristics characteristics) {
        if (characteristics == null) {
            throw new IllegalArgumentException("CameraCharacteristics is null");
        }

        CameraCharacteristics.Key<?> supportKey = findCharacteristicKey(
                characteristics.getKeys(), CHARACTERISTIC_SUPPORT_TAG);
        boolean supportPublished = supportKey != null;
        boolean supportTypeMatches = supportPublished
                && supportKey.getType() == int[].class;
        int[] supportValues = null;

        if (supportTypeMatches) {
            try {
                @SuppressWarnings("unchecked")
                CameraCharacteristics.Key<int[]> typedKey =
                        (CameraCharacteristics.Key<int[]>) supportKey;
                int[] values = characteristics.get(typedKey);
                supportValues = values == null ? null : values.clone();
            } catch (RuntimeException ignored) {
                // Keep inspection available even if a vendor characteristic
                // is advertised but cannot be read by this camera client.
            }
        }

        CaptureRequest.Key<?> requestKey = findRequestKey(
                characteristics.getAvailableCaptureRequestKeys(), REQUEST_MODE_TAG);
        boolean requestPublished = requestKey != null;
        boolean requestTypeMatches = requestPublished
                && requestKey.getType() == int[].class;

        CaptureResult.Key<?> resultKey = findResultKey(
                characteristics.getAvailableCaptureResultKeys(), REQUEST_MODE_TAG);
        boolean resultPublished = resultKey != null;
        boolean resultTypeMatches = resultPublished
                && resultKey.getType() == int[].class;

        return new SupportInfo(
                supportPublished,
                supportTypeMatches,
                supportValues,
                supportKey == null ? null : supportKey.getType().getName(),
                requestPublished,
                requestTypeMatches,
                requestKey == null ? null : requestKey.getType().getName(),
                resultPublished,
                resultTypeMatches,
                resultKey == null ? null : resultKey.getType().getName());
    }

    /**
     * Adds the raw Transsion OIS value to a CaptureRequest builder.
     *
     * @throws UnsupportedOperationException if this camera does not advertise
     *         the exact request key.
     * @throws IllegalStateException if the published key is not int[].
     */
    public static void applyRawMode(
            CameraCharacteristics characteristics,
            CaptureRequest.Builder builder,
            int rawValue) {
        if (characteristics == null) {
            throw new IllegalArgumentException("CameraCharacteristics is null");
        }
        if (builder == null) {
            throw new IllegalArgumentException("CaptureRequest.Builder is null");
        }

        CaptureRequest.Key<?> discovered = findRequestKey(
                characteristics.getAvailableCaptureRequestKeys(), REQUEST_MODE_TAG);

        if (discovered == null) {
            throw new UnsupportedOperationException(
                    "Camera does not advertise " + REQUEST_MODE_TAG);
        }
        if (discovered.getType() != int[].class) {
            throw new IllegalStateException(
                    "Unexpected type for " + REQUEST_MODE_TAG + ": "
                            + discovered.getType().getName());
        }

        @SuppressWarnings("unchecked")
        CaptureRequest.Key<int[]> typedKey =
                (CaptureRequest.Key<int[]>) discovered;
        builder.set(typedKey, new int[]{rawValue});
    }

    /**
     * Reads a vendor result only if the camera advertises a result key with
     * the same exact name and int[] type. Returns null when no such result key
     * is published or the result value is unavailable.
     *
     * NOTE: The current research project has not established that Transsion
     * publishes a result key named com.transsion.tranOisMode. This method is
     * a guarded probe, not an assertion that such a result exists.
     */
    public static int[] readVendorResult(
            CameraCharacteristics characteristics,
            CaptureResult result) {
        if (characteristics == null || result == null) {
            return null;
        }

        CaptureResult.Key<?> discovered = findResultKey(
                characteristics.getAvailableCaptureResultKeys(), REQUEST_MODE_TAG);
        if (discovered == null || discovered.getType() != int[].class) {
            return null;
        }

        try {
            @SuppressWarnings("unchecked")
            CaptureResult.Key<int[]> typedKey =
                    (CaptureResult.Key<int[]>) discovered;
            int[] value = result.get(typedKey);
            return value == null ? null : value.clone();
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private static CameraCharacteristics.Key<?> findCharacteristicKey(
            List<CameraCharacteristics.Key<?>> keys, String exactName) {
        if (keys == null) return null;
        for (CameraCharacteristics.Key<?> key : keys) {
            if (key != null && exactName.equals(key.getName())) return key;
        }
        return null;
    }

    private static CaptureRequest.Key<?> findRequestKey(
            List<CaptureRequest.Key<?>> keys, String exactName) {
        if (keys == null) return null;
        for (CaptureRequest.Key<?> key : keys) {
            if (key != null && exactName.equals(key.getName())) return key;
        }
        return null;
    }

    private static CaptureResult.Key<?> findResultKey(
            List<CaptureResult.Key<?>> keys, String exactName) {
        if (keys == null) return null;
        for (CaptureResult.Key<?> key : keys) {
            if (key != null && exactName.equals(key.getName())) return key;
        }
        return null;
    }

    public static final class SupportInfo {
        public final boolean supportCharacteristicPublished;
        public final boolean supportCharacteristicTypeMatches;
        private final int[] supportValues;
        public final String supportCharacteristicType;

        public final boolean requestKeyPublished;
        public final boolean requestKeyTypeMatches;
        public final String requestKeyType;

        public final boolean resultKeyPublished;
        public final boolean resultKeyTypeMatches;
        public final String resultKeyType;

        private SupportInfo(
                boolean supportCharacteristicPublished,
                boolean supportCharacteristicTypeMatches,
                int[] supportValues,
                String supportCharacteristicType,
                boolean requestKeyPublished,
                boolean requestKeyTypeMatches,
                String requestKeyType,
                boolean resultKeyPublished,
                boolean resultKeyTypeMatches,
                String resultKeyType) {
            this.supportCharacteristicPublished = supportCharacteristicPublished;
            this.supportCharacteristicTypeMatches = supportCharacteristicTypeMatches;
            this.supportValues = supportValues == null ? null : supportValues.clone();
            this.supportCharacteristicType = supportCharacteristicType;
            this.requestKeyPublished = requestKeyPublished;
            this.requestKeyTypeMatches = requestKeyTypeMatches;
            this.requestKeyType = requestKeyType;
            this.resultKeyPublished = resultKeyPublished;
            this.resultKeyTypeMatches = resultKeyTypeMatches;
            this.resultKeyType = resultKeyType;
        }

        public boolean isRequestKeyUsable() {
            return requestKeyPublished && requestKeyTypeMatches;
        }

        public int[] getSupportValues() {
            return supportValues == null ? null : supportValues.clone();
        }

        @Override
        public String toString() {
            return "SupportInfo{" +
                    "supportCharacteristicPublished=" + supportCharacteristicPublished +
                    ", supportCharacteristicTypeMatches=" + supportCharacteristicTypeMatches +
                    ", supportValues=" + Arrays.toString(supportValues) +
                    ", supportCharacteristicType='" + supportCharacteristicType + '\'' +
                    ", requestKeyPublished=" + requestKeyPublished +
                    ", requestKeyTypeMatches=" + requestKeyTypeMatches +
                    ", requestKeyType='" + requestKeyType + '\'' +
                    ", resultKeyPublished=" + resultKeyPublished +
                    ", resultKeyTypeMatches=" + resultKeyTypeMatches +
                    ", resultKeyType='" + resultKeyType + '\'' +
                    '}';
        }
    }
}
