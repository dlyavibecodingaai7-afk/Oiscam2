    # ============================================================
    # TRANSSION OIS - FORCE ENABLE (candidate value = 1)
    # Вставь этот блок прямо перед последним return-void метода f()
    # ============================================================
    :try_start_transsion
    const-string v0, "com.transsion.tranOisMode"

    const-class v1, [I

    new-instance v2, Landroid/hardware/camera2/CaptureRequest$Key;

    invoke-direct {v2, v0, v1}, Landroid/hardware/camera2/CaptureRequest$Key;-><init>(Ljava/lang/String;Ljava/lang/Class;)V

    const/4 v0, 0x1

    new-array v0, v0, [I

    const/4 v1, 0x0

    const/4 v3, 0x1

    aput v3, v0, v1

    invoke-virtual {p1, v2, v0}, Landroidx/camera/camera2/interop/CaptureRequestOptions$Builder;->setCaptureRequestOption(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)Landroidx/camera/camera2/interop/CaptureRequestOptions$Builder;

    const-string v0, "RawCamManager"

    const-string v1, "Applied Transsion OIS vendor tag: tranOisMode=1"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_transsion
    .catch Ljava/lang/Exception; {:try_start_transsion .. :try_end_transsion} :catch_transsion

    goto :cond_transsion_end

    :catch_transsion
    move-exception v0

    const-string v1, "RawCamManager"

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const-string v2, "Failed to apply Transsion OIS: "

    invoke-static {v2, v0, v1}, LC0/c;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_transsion_end
    # === END TRANSSION OIS ===
